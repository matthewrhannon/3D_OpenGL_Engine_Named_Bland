
//********************************************
//					NeheFont
//********************************************


#pragma once

#include "Globals.h"
#include "Texture.h"
#include "Windows98.h"
#include "Engine.h"

class CWindowsFont
{
	public:
		CWindowsFont();

		~CWindowsFont();

		void BuildFont(char *FontName, int Height);
		
		void RenderText(int x, int y, char *String);

		void SetFontColor(int pRed, int pGreen, int pBlue, int pAlpha);

		void KillFont();

	private:
		int Red, Green, Blue, Alpha;

		int base;
		int set;

		HFONT font;
};

CWindowsFont::CWindowsFont()
{
	Red = 255;
	Green = 0;
	Blue = 0;
	Alpha = 1;
}

CWindowsFont::~CWindowsFont()
{
	KillFont();
}

void CWindowsFont::BuildFont(char *FontName, int Height)					
{		
	HFONT	font;									
	HFONT	oldfont;							

	base = glGenLists(96);							

	font = CreateFont(Height, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,	FF_DONTCARE | DEFAULT_PITCH, FontName);					

	oldfont = (HFONT)SelectObject(g_hdc, font);          
	wglUseFontBitmaps(g_hdc, 32, 96, base);				
	SelectObject(g_hdc, oldfont);						
	DeleteObject(font);														
}


void CWindowsFont::RenderText(int x, int y, char *String)			
{						
	if (!strlen(String))								
		return;											

	glPushAttrib(GL_ALL_ATTRIB_BITS);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
		
		glListBase(base-32);					
			
		glPushMatrix();
		glLoadIdentity();
		glMatrixMode(GL_PROJECTION);			
		glPushMatrix();
			glLoadIdentity();

			glColor4ub(Red, Green, Blue, Alpha);
			glOrtho(0.0f, 640, 0.0f, 480.0f, -1.0f, 1.0f);
		
			glBlendFunc(GL_ONE, GL_ONE);

			glRasterPos2i(x, y);							

			glCallLists(strlen(String), GL_UNSIGNED_BYTE, String);	
		glPopMatrix();
		glMatrixMode(GL_MODELVIEW);
		glPopMatrix();
	glPopAttrib();
	glColor3f(255, 255, 255);
}

void CWindowsFont::KillFont()								
{
	glDeleteLists(base, 96);
	DeleteObject(font);	
}
	
void CWindowsFont::SetFontColor(int pRed, int pGreen, int pBlue, int pAlpha)
{
	if(pRed > 255)
		pRed = 255;
	if(pGreen > 255)
		pGreen = 255;
	if(pBlue > 255)
		pBlue = 255;

	Red = pRed;
	Green = pGreen;
	Blue = pBlue;

	Alpha = pAlpha;
}
