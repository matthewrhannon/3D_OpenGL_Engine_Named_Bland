
////////////////////////////////////////////
//					Images
////////////////////////////////////////////

#pragma once

#include "Globals.h"
#include "Log.h"
#include "Structures.h"
#include "Extensions.h"

class CFileInfo
{
	public:
		CFileInfo()
		{
			SkyBox = false;
			Start = false;
		}

		~CFileInfo();
		
		void UseTexture();
		void GetInfo(FILEINFO &Info);
		void SetInfo(char *File1, int SizeX1, int SizeY1, unsigned int ID1[1], bool SkyBox1);
		void Restart();

		void KillObject();

		int SizeX; //Sometimes i hate private parts of classes
		char File[64];
		
		int SizeY;

		unsigned int ID[1];

		bool SkyBox;
		bool Start;

	private:
		//FUCK IT
};

CFileInfo::~CFileInfo()
{
	//Fuck it, it can die for all i care!! HAHHAHA i told it!
}

void CFileInfo::KillObject()
{
	if(ID)
		glDeleteTextures(1, &ID[0]);
}

void CFileInfo::UseTexture()
{
	if(ID)
		glBindTexture(GL_TEXTURE_2D, ID[0]);
}

void CFileInfo::Restart()
{	
	SizeX = 0;
	SizeY = 0;
	ID[0] = -1;
	SkyBox = NULL;
	strcpy(File, "");
}

void CFileInfo::SetInfo(char *File1, int SizeX1, int SizeY1, unsigned int ID1[1], bool SkyBox1)
{
	strcpy(File, File1);
	SizeX = SizeX1;
	SizeY = SizeY1;
	ID[0] = ID1[0];
	SkyBox = SkyBox1;

	CLog::Get()->WriteEx("Loading Info: %s XY: %d-%d  ID: %d SkyBox: %d", File1, SizeX1, SizeY1, ID1, SkyBox1);
}

void CFileInfo::GetInfo(FILEINFO &Info)
{
	strcpy(Info.File, File);
	Info.SizeX = SizeX;
	Info.SizeY = SizeY;
	Info.ID = ID[0];
	Info.SkyBox = SkyBox;
}

/////////////////////////////////////////////////////////////////////////

class CImage
{
	public:
		static CImage *Get()
		{
			if(!Instance)
				Instance = new CImage;
			return Instance;
		}
	
		CImage()
		{
			SkyBox = false;
			
			CLog::Get()->LineDown();
			CLog::Get()->Write("Loading Textures");
		}

		void LoadBMPData(char *FilePath, unsigned char *Data);
		
		///////////////////
		
		CFileInfo LoadBMP(char *File);
		
		CFileInfo LoadBMPEx(char *File, unsigned char *Data);
		CFileInfo LoadGIF(char *File);
		CFileInfo LoadJPEG(char *File);
		CFileInfo LoadTGA(char *File);
		CFileInfo LoadEMF(char *File);
		CFileInfo LoadICO(char *File);
		CFileInfo LoadWMF(char *File);
		
		CFileInfo LoadMisc(char *File);

		void SetSkyBox(bool State)
		{
			SkyBox = State;
		}

		void CensorOutColor(int B, int G, int R);
		void NoCensorColor();

	protected:
		~CImage()
		{
			if(Instance)
				delete Instance;
			Instance = 0;

			CLog::Get()->LineDown();
			CLog::Get()->Write("Finished Loading Textures");
		}

	private:
		static CImage *Instance;
		
		AUX_RGBImageRec *Image[1];	
		FILE *File;	

		bool SkyBox;
		bool Censor;

		int Red, Green, Blue;
};

CImage *CImage::Instance = 0;

void CImage::LoadBMPData(char *FilePath, unsigned char *Data)
{
	Data = NULL;
	
	CLog::Get()->WriteEx("Trying to load: %s!", FilePath);
	
	memset(Image,0,sizeof(void *)*1); 

	if (!strlen(FilePath))									
	{
		CLog::Get()->WriteError("String Passed in to BMP isnt Valid. String = %s",  FilePath);
		
		return;
	}

	File = fopen(FilePath,"r");						

	if (File)										
	{
		Image[0] = auxDIBImageLoad(FilePath);
		fclose(File);													
	}

	Data = Image[0]->data;
	
	if (Image[0])								
	{	
		if (Image[0]->data)							
			free(Image[0]->data);					
	
		free(Image[0]);		
	}

	CLog::Get()->WriteEx("Load for %s was sucessful!", FilePath);
}

void CImage::CensorOutColor(int B, int G, int R)
{
	Red = R;
	Green = G;
	Blue = B;

	Censor = true;
}

void CImage::NoCensorColor()
{
	Censor = false;
}

CFileInfo CImage::LoadBMP(char *FilePath)
{
	CFileInfo Temp;
	unsigned int Id[1];

	Id[0] = 0;

	Temp.Restart();

	CLog::Get()->LineDown();
	CLog::Get()->WriteEx("Trying to load: %s!", FilePath);

	memset(Image,0,sizeof(void *)*1); 

	if (!strlen(FilePath))									
	{
		CLog::Get()->WriteError("String Passed in to BMP isnt Valid. String = %s",  FilePath);
		
		return Temp;
	}

	File = fopen(FilePath,"r");						

	if (!File)										
	{
		CLog::Get()->WriteError("Couldnt Load %s!  Couldn't read the file!", FilePath);	
		return Temp;
	}
	
	Image[0] = auxDIBImageLoad(FilePath);
	fclose(File);	

	if (Image[0])
	{
		glGenTextures(1, &Id[0]);				
		glBindTexture(GL_TEXTURE_2D, Id[0]);
	
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);

		if(SkyBox)
		{
			unsigned int ClampMode; 
			
			if (GetExtension("GL_EXT_texture_edge_clamp"))
			{
				CLog::Get()->Write("GL_EXT_texture_edge_clamp supported, using it to enhance skybox");
				ClampMode = GL_CLAMP_TO_EDGE; 
			}
			else 
			{
				CLog::Get()->Write("GL_EXT_texture_edge_clamp not supported, instead using alternative to enchance skybox");
				ClampMode = GL_CLAMP; 
			}

			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, ClampMode); 
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, ClampMode); 
		}
	
		gluBuild2DMipmaps(GL_TEXTURE_2D, 3, Image[0]->sizeX, Image[0]->sizeY, GL_RGB, GL_UNSIGNED_BYTE, Image[0]->data);
	}
	else
		CLog::Get()->WriteError("Couldnt Load %s!  Possibly File Missing", FilePath);
	
	Temp.SetInfo(FilePath, Image[0]->sizeX, Image[0]->sizeY, Id, SkyBox);
	/*
	if (Image[0])								
	{	
		if (Image[0]->data)							
			free(Image[0]->data);					
	
		free(Image[0]);		
	}
	*/
	CLog::Get()->WriteEx("Load for %s was sucessful!", FilePath);

	return Temp;
}

CFileInfo CImage::LoadGIF(char *File)
{
	CFileInfo Temp;

	Temp = LoadMisc(File);

	return Temp;
}

CFileInfo CImage::LoadJPEG(char *File)
{
	CFileInfo Temp;

	Temp = LoadMisc(File);

	return Temp;
}

CFileInfo CImage::LoadTGA(char *File)
{
	//......HAVE TO DO FORMAT
	
	CFileInfo Info;
	
	Info.SetInfo(NULL, NULL, NULL, NULL, NULL);

	return Info;
}

CFileInfo CImage::LoadEMF(char *File)
{
	CFileInfo Temp;

	Temp = LoadMisc(File);

	return Temp;
}
	
CFileInfo CImage::LoadICO(char *File)
{
	CFileInfo Temp;

	Temp = LoadMisc(File);

	return Temp;
}
	
CFileInfo CImage::LoadWMF(char *File)
{
	CFileInfo Temp;

	Temp = LoadMisc(File);

	return Temp;
}

CFileInfo CImage::LoadBMPEx(char *FilePath, unsigned char *Data)
{
//	LoadBMPData(File, Data);
	CFileInfo Shit;
	return Shit;
}

CFileInfo CImage::LoadMisc(char *szPathName)
{
	//Alot of thanks to NeHe for this great picture code
	//This is all his code just cleaned up a bit and updated for my project
	//Thanks NeHe!!

	HDC			hdcTemp;												
	HBITMAP		hbmpTemp;												
	IPicture	*pPicture;												
	OLECHAR		wszPath[MAX_PATH+1];								
	char		szPath[MAX_PATH+1];									
	long		lWidth;													
	long		lHeight;												
	long		lWidthPixels;										
	long		lHeightPixels;											
	GLint		glMaxTexDim ;

	CFileInfo Temp;

	Temp.Restart();

	CLog::Get()->LineDown();
	CLog::Get()->WriteEx("Trying to load: %s with NeHe's Code", szPathName);


	if(!strlen(szPathName))
	{	
		CLog::Get()->WriteError("String Passed in to Misc isnt Valid. String = %s",  szPathName);
		
		return Temp;
	}

	if (strstr(szPathName, "http://"))								
	{
		strcpy(szPath, szPathName);									
	}
	else																
	{
		GetCurrentDirectory(MAX_PATH, szPath);							
		strcat(szPath, "\\");										
		strcat(szPath, szPathName);									
	}

	MultiByteToWideChar(CP_ACP, 0, szPath, -1, wszPath, MAX_PATH);		
	HRESULT hr = OleLoadPicturePath(wszPath, 0, 0, 0, IID_IPicture, (void**)&pPicture);

	if(FAILED(hr))													
	{
		CLog::Get()->WriteError("Something went wrong while creating the OLE. String = %s", szPath);

		return Temp;										

	}
	
	hdcTemp = CreateCompatibleDC(GetDC(0));							
	if(!hdcTemp)													
	{
		CLog::Get()->WriteError("Error in Creating DC. String = %s",  szPath);
		
		pPicture->Release();	
		
		return Temp;											
	}

	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &glMaxTexDim);					
	
	pPicture->get_Width(&lWidth);									
	lWidthPixels	= MulDiv(lWidth, GetDeviceCaps(hdcTemp, LOGPIXELSX), 2540);
	pPicture->get_Height(&lHeight);									
	lHeightPixels	= MulDiv(lHeight, GetDeviceCaps(hdcTemp, LOGPIXELSY), 2540);

	if (lWidthPixels <= glMaxTexDim) 
		lWidthPixels = 1 << (int)floor((log((double)lWidthPixels)/log(2.0f)) + 0.5f); 
	else 
		lWidthPixels = glMaxTexDim;
 
	if (lHeightPixels <= glMaxTexDim) 
		lHeightPixels = 1 << (int)floor((log((double)lHeightPixels)/log(2.0f)) + 0.5f);
	else  
		lHeightPixels = glMaxTexDim;
	
	BITMAPINFO	bi = {0};												
	DWORD		*pBits = 0;											

	bi.bmiHeader.biSize			= sizeof(BITMAPINFOHEADER);				
	bi.bmiHeader.biBitCount		= 32;									
	bi.bmiHeader.biWidth		= lWidthPixels;						
	bi.bmiHeader.biHeight		= lHeightPixels;					
	bi.bmiHeader.biCompression	= BI_RGB;							
	bi.bmiHeader.biPlanes		= 1;							

	hbmpTemp = CreateDIBSection(hdcTemp, &bi, DIB_RGB_COLORS, (void**)&pBits, 0, 0);
	
	if(!hbmpTemp)													
	{
		CLog::Get()->WriteError("Couldnt Create Handle for DIB Section. String = %s",  szPath);
		
		DeleteDC(hdcTemp);											
		pPicture->Release();	
		
		return Temp;													
	}

	SelectObject(hdcTemp, hbmpTemp);									
	
	pPicture->Render(hdcTemp, 0, 0, lWidthPixels, lHeightPixels, 0, lHeight, lWidth, -lHeight, 0);

	for(long i = 0; i < lWidthPixels * lHeightPixels; i++)				
	{
		BYTE* pPixel	= (BYTE*)(&pBits[i]);							
		BYTE  temp		= pPixel[0];									
		pPixel[0]		= pPixel[2];								
		pPixel[2]		= temp;											

		if(Censor)
		{
			if ((pPixel[0]==Red) && (pPixel[1]==Green) && (pPixel[2]==Blue))			
				pPixel[3]	=   0;										
			else													
				pPixel[3]	= 255;	
		}
	}

	unsigned int texid[1];

	glGenTextures(1, &texid[0]);									

	glBindTexture(GL_TEXTURE_2D, texid[0]);								

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);

	if(SkyBox)
	{
		unsigned int ClampMode; 
		
		if (GetExtension("GL_EXT_texture_edge_clamp"))
		{
			CLog::Get()->Write("GL_EXT_texture_edge_clamp supported, using it to enhance skybox");
			ClampMode = GL_CLAMP_TO_EDGE; 
		}
		else 
		{
			CLog::Get()->Write("GL_EXT_texture_edge_clamp not supported, instead using alternative to enchance skybox");
			ClampMode = GL_CLAMP; 
		}
	
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, ClampMode); 
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, ClampMode);             
	}

	gluBuild2DMipmaps(GL_TEXTURE_2D, 4, lWidthPixels, lHeightPixels, GL_RGBA, GL_UNSIGNED_BYTE, pBits);

	DeleteObject(hbmpTemp);											
	DeleteDC(hdcTemp);												

	pPicture->Release();	

	Temp.SetInfo(szPath, lWidthPixels, lHeightPixels, texid, SkyBox);

	CLog::Get()->WriteEx("Load for %s was sucessful!", szPath);	
	
	return Temp;
}
