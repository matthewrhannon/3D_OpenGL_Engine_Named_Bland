//include the shit
//from the 2 other fils

//********************************************
//					Text
//********************************************

#pragma once

#include "Globals.h"

#include "WindowFont.h"
#include "NeheFont.h"

#define FONT_NEHE	  0
#define FONT_WINDOWS  1

#if defined(DrawText)
#undef DrawText
#endif

class CText
{
	public:
		CText();
		~CText();

		bool LoadFont(int pType, int pSize, char *pFontName);
	
		void RenderText(int x, int y, char *Text, ...);

		void SetFontColor(int Red1, int Green1, int Blue1, int Alpha1);
		void SetFontSize(int SizeX, int SizeY);

	private:
		int Type;
		int Size;
		char FontName[32];

		char String[1024];

		va_list ap;	

		CNeheFont Nehe;
		CWindowsFont Windows;
};

CText::CText()
{
	Type = 0;
	Size = 0;

	strcpy(FontName, "");
}

CText::~CText()
{

}

void CText::SetFontColor(int Red1, int Green1, int Blue1, int Alpha1)
{
	if(Type == FONT_NEHE)
		Nehe.SetFontColor(Red1, Green1, Blue1, Alpha1);
	if(Type == FONT_WINDOWS)
		Windows.SetFontColor(Red1, Green1, Blue1, Alpha1);
}

void CText::SetFontSize(int SizeX, int SizeY)
{
	Nehe.SetTextSize(SizeX, SizeY);
}

bool CText::LoadFont(int pType, int pSize, char *pFontName)
{ 
	Type = pType;

	if(Type == FONT_NEHE)
	{
		Nehe.BuildFont();
	}
	if(Type == FONT_WINDOWS)
	{
		Size = pSize;
		strcpy(FontName, pFontName);
		Windows.BuildFont(FontName, pSize);
	}
	
	return true;
}

void CText::RenderText(int x, int y, char *Text, ...)
{
	if(Type == FONT_WINDOWS)
	{								
		va_start(ap, Text);									
			vsprintf(String, Text, ap);							
		va_end(ap);	
		
		Windows.RenderText(x, y, String);
	}
	if(Type == FONT_NEHE)
	{								
		va_start(ap, Text);									
			vsprintf(String, Text, ap);							
		va_end(ap);	

		Nehe.RenderText(x, y, String);
	}

}


