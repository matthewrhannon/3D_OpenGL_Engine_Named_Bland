//possibly updated model code here. possibly bullet and all that here also
//but not collison. it needsx to be in the collision shit. but updating here