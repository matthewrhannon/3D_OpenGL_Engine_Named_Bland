/////////////////////////////////////////
//					Object
/////////////////////////////////////////

/////////TODOOOOOOOOO///////
//Make add one for nodes
//think about it
//make good
///////////////////////////

#pragma once

#include "Globals.h"
#include "Vector.h"

class CObject
{
	public:
		CObject();
		~CObject();

		void GetPosition(CVector &Position1);
		CVector GetVelocity();

		void GetOldPosition(CVector &Position1);
		void GetNewPosition(CVector &Position1);

		CVector GetConstantVelocity();
		
		void SetConstantVelocity(CVector Vel);

		void SetPosition(CVector tPos);
		void SetVelocity(CVector tVel);
		
		void SetOldPosition(CVector tPos);
		void SetNewPosition(CVector tPos);

		CVector Position;
		CVector Velocity;

		CVector OldPosition;
		CVector NewPosition;

		CVector ConstantVelocity;

		CVector View;

	protected:
		virtual void InitializeOjbect();
		virtual void UpdateObject(float TimeBased);
		virtual void UpdateAI(float TimeBased);
		virtual void UpdatePhysics(float TimeBased);
		virtual void DestroyObject();
};

CObject::CObject()
{
	Position.Clear();
	Velocity.Clear();

	OldPosition.Clear();
	NewPosition.Clear();

	ConstantVelocity.Clear();

	View.Clear();
}

CObject::~CObject()
{

}

void CObject::GetPosition(CVector &Position1)
{
	Position1.Set(Position);
}

CVector CObject::GetVelocity()
{
	return Velocity;
}

void CObject::GetOldPosition(CVector &Position1)
{
	Position1.Set(OldPosition);
}

void CObject::GetNewPosition(CVector &Position1)
{
	Position1.Set(NewPosition);
}

CVector CObject::GetConstantVelocity()
{
	return ConstantVelocity;
}

void CObject::SetConstantVelocity(CVector Vel)
{
	ConstantVelocity.Set(Vel);
}

void CObject::SetPosition(CVector tPos)
{
	Position.Set(tPos);
}

void CObject::SetVelocity(CVector tVel)
{
	Velocity.Set(tVel);
}

void CObject::SetOldPosition(CVector tPos)
{
	OldPosition.Set(tPos);
}

void CObject::SetNewPosition(CVector tPos)
{
	NewPosition.Set(tPos);
}

void CObject::InitializeOjbect()
{

}

void CObject::UpdateObject(float TimeBased)
{

}

void CObject::UpdateAI(float TimeBased)
{



}

void CObject::UpdatePhysics(float TimeBased)
{


}

void CObject::DestroyObject()
{


}





