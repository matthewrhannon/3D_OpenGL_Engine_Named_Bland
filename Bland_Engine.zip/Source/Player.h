/////////////////////////////////////////////
//					Player
/////////////////////////////////////////////

#pragma once

#include "Globals.h"
#include "Log.h"
#include "Object.h"
#include "Vector.h"
#include "Timer.h"
#include "Text.h"
#include "NeheFont.h"

CText PLZ;
CText PL;

class CPlayer : public CObject
{
	public:
		static CPlayer *Get()
		{
			if(!Instance)
				Instance = new CPlayer;
			return Instance;
		}
		
		CPlayer();
		~CPlayer();

		void UpdateObject(float TimeBased);
		void UpdateAI(float Timebased);
		void UpdatePhysics(float TimeBased);

	private:
		static CPlayer *Instance;
		bool Jumping;
};

CPlayer *CPlayer::Instance = 0;

CPlayer::CPlayer()
{
	CLog::Get()->LineDown();
	CLog::Get()->Write("Creating Object Player");

	Jumping = false;

//	PLZ.SetFontColor(255, 0, 255, 1);
//	PLZ.SetFontSize(1, 1);
	PLZ.LoadFont(FONT_NEHE, 0, "");
}

CPlayer::~CPlayer()
{

}

void CPlayer::UpdateObject(float TimeBased)
{
	Velocity.x += ConstantVelocity.x * TimeBased;
	Velocity.y += ConstantVelocity.y * TimeBased;
	Velocity.z += ConstantVelocity.z * TimeBased;

	OldPosition.Set(Position);

	Position.x += Velocity.x * TimeBased;
	Position.y += Velocity.y * TimeBased;	
	Position.z += Velocity.z * TimeBased;
	
	Velocity.Clear();

	//PLZ.RenderText(0,50, "X: %f Y: %f Z: %f", Position.x, Position.y, Position.z);
}

void CPlayer::UpdateAI(float TimeBased)
{


}

void CPlayer::UpdatePhysics(float TimeBased)
{



}
