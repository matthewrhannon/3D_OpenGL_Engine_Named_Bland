//MAKE SURE YOU CAN updat eall entitys at once if you want. use nodes or something.. i dont know
//use global varibles