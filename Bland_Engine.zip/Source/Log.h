
//********************************************//
//				Log System
//********************************************//

#pragma once 

#include "Globals.h"
#include "Structures.h"
#include "Extensions.h"
#include "Engine.h"

//********************************************

////////TODO////////
//CHECK Make sure you use a msgboxerror message down below and also
//CHECK � Get the Gl Info done and also. put in the release date for the header
//CHECK � The version stuff. and also more information would be nice
//CHECK Needs alot of testing too :)
//CHECK I can only imagine what it is going to be like when i try to compile. 555555555555 errors
//CHECK Do titles for each of the special log write functions.,
//PUT A TIME LEFT AND STUFF AT END OF THE LOG AVEGE FPS ETCCCCCC
//CHECK SOMEONE HOW FIX THE FUCKEN WRITEERROR SHIT AND FIX THE GLGETSTRING SHIT PLZZZZZZZZZ



//CHECK FIX THE GL RENDER LOG SHIIIIIIIIIIIIIIITTTTTTTTTTTTTTTTTTTTT



//MAKE IT SO IF THERE IS AN ERROR THE LOG ACTUALLY SHOWS UP
///////TODO////////

class CLog
{
	public:
		static CLog *Get()
		{
			if(!Instance)
				Instance = new CLog;
			return Instance;
		}

		CLog();
		~CLog();

		void Load();
		void UnLoad();
		
		void Write(char *Text);
		void WriteEx(char *Text, ...);

		void WriteHeader();
		void WriteGLInfo();
		void WriteCompInfo();

		void WriteError(char *Text1, ...);
		void LineDown();

		bool RequestExtensions();

	private:
		static CLog *Instance;
		FILE *LogFile;

		bool Extensions;
		char TempString[64];
		char TempString1[64];
		char ExtensionString[512];
		char LogPath[32];
};

//******************************************

CLog *CLog::Instance = 0;

CLog::CLog()
{
	LogFile = NULL;
	Extensions = false;

	strcpy(LogPath, "BlandLog.txt");
}

CLog::~CLog()
{
	if(Instance)
		delete Instance;
	Instance = 0;
}

void CLog::Load()
{
	if(!LogFile)
		LogFile = fopen(LogPath, "w");

	fputs("******************************", LogFile);
	
	//WriteHeader(); 
//	WriteGLInfo();
	//WriteCompInfo();

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::UnLoad()
{
	if(!LogFile)
		LogFile = fopen(LogPath, "w");

//	LineDown();
//	fputs("\n******************************", LogFile);
	
	if(LogFile)
		fclose(LogFile);
	LogFile = NULL;
}

void CLog::Write(char *Text)
{
	static char Text1[256];

	if(!strlen(Text))
		return;

	if(!LogFile)
		LogFile = fopen(LogPath, "w");


	sprintf(Text1, "\n%s", Text);

	fputs(Text1, LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::WriteEx(char *Text, ...)
{
	static char Text1[256];
	
	if(!strlen(Text))
		return;
	
	va_list List;
	char Temp[256];

	va_start(List, Text);
		vsprintf(Temp, Text, List);
	va_end(List);

	if(!LogFile)
		LogFile = fopen(LogPath, "w");

	sprintf(Text1, "\n%s", Temp);

	fputs(Text1, LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}
void CLog::WriteGLInfo()
{
	if(!LogFile)
		LogFile = fopen(LogPath, "w");

	if(LogFile)
	{
		fputs("\n****************", LogFile);
		sprintf(TempString, "\n   OpenGL Info");
		fputs(TempString, LogFile);
		sprintf(TempString, "\nVendor: %s", (char *)glGetString(GL_VENDOR));
		fputs(TempString, LogFile);
		sprintf(TempString, "\nRenderer: %s", (char *)glGetString(GL_RENDERER));
		fputs(TempString, LogFile);
		sprintf(TempString, "\nVersion: %s", (char *)glGetString(GL_VERSION));
		fputs(TempString, LogFile);
		
		if(Extensions)
		{
			sprintf(ExtensionString, "\nExtensions: %s", (char *)glGetString(GL_EXTENSIONS));
		
			int Counter = 0;
	
			for(int x = 0; x < (int)strlen(ExtensionString); x++)
			{
				if(ExtensionString[x] == ' ')
				{
					fputc('\n', LogFile);

					for(int y = x-Counter; y < x; y++)
					{
						fputc((char)ExtensionString[y], LogFile);
					}
		
					Counter = 0;
				}
			
				Counter++;
			}
		}

		fputs("\n*****************", LogFile);
	}

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::WriteCompInfo()
{
	SYSTEMTIME Time;
	GetLocalTime(&Time);

	if(!LogFile)
		LogFile = fopen(LogPath, "w");

	if(LogFile)
	{
		fputs("\n****************", LogFile);
		sprintf(TempString, "\n   Comp Info");
		fputs(TempString, LogFile);
		sprintf(TempString, "\nTime: %d:%d", Time.wHour, Time.wMinute);
		fputs(TempString, LogFile);
		sprintf(TempString, "\nDate: %d/%d/%d", Time.wMonth, Time.wDay, Time.wYear);
		fputs(TempString, LogFile);
		fputs("\n****************", LogFile);
		LineDown();
	}
	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::WriteHeader()
{
	if(!LogFile)
		LogFile = fopen(LogPath, "w");

	if(LogFile)
	{
		fputs("\n****************", LogFile);
		sprintf(TempString, "\n   Engine Info");
		fputs(TempString, LogFile);
		fputs("\nEngine Name Bland", LogFile);
		fputs("  \nBy Matthew Hannon", LogFile);
		sprintf(TempString, "\nVersion: %s", EngineVersion);
		fputs(TempString, LogFile);
		fputs("\n****************", LogFile);
	}

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::WriteError(char *Text1, ...)
{
	va_list TempList1;

	if(!strlen(Text1))
		return;

	va_start(TempList1, Text1);
		vsprintf(TempString1, Text1, TempList1);
	va_end(TempList1);
		
	if(!LogFile)
		LogFile = fopen(LogPath, "w");

	sprintf(TempString1, "\n   %s", TempString1);

	fputs(TempString1, LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

void CLog::LineDown()
{
	if(!LogFile)
		LogFile = fopen(LogPath, "w");

	fputc('\n', LogFile);

	if(LogFile)
	{
		fclose(LogFile);
		LogFile = NULL;
	}
}

bool CLog::RequestExtensions()
{
	Extensions = true;

	return true;

}
