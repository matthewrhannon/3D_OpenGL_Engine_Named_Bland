//update enemy movement.
//do AI here. uose stat machine to be doin certain things.
//Should model get updated if not in frustu,m?
//yes. but NOT drawn.
///do object being created shit with log here