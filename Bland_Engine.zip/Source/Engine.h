//********************************************
//					Engine
//********************************************

#pragma once

#include "Globals.h"
#include "Structures.h"
#include "Windows98.h"
#include "Log.h"
#include "Timer.h"
#include "Texture.h"
#include "Text.h"
#include "Camera.h"
#include "Vector.h"
#include "Input.h"
#include "Player.h"
#include "Sky.h"

CFileInfo Sky;
CText Example;

void Draw3DSGrid()
{
	// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	float i;
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);

			// Do the horizontal lines (along the X)
			glVertex3f(-50, 0, i);
			glVertex3f(50, 0, i);

			// Do the vertical lines (along the Z)
			glVertex3f(i, 0, -50);
			glVertex3f(i, 0, 50);

		// Stop drawing lines
		glEnd();
	}

// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);

			// Do the horizontal lines (along the X)
			glVertex3f(-50, 10, i);
			glVertex3f(50, 10, i);

			// Do the vertical lines (along the Z)
			glVertex3f(i, 10, -50);
			glVertex3f(i, 10, 50);

		// Stop drawing lines
		glEnd();
	}

// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);

			// Do the horizontal lines (along the X)
			glVertex3f(-50, 0, i);
			glVertex3f(-50, 10, i);
		// Stop drawing lines
		glEnd();
	}

// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);

			// Do the horizontal lines (along the X)
			glVertex3f(50, 0, i);
			glVertex3f(50, 10, i);
		// Stop drawing lines
		glEnd();
	}

// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);

			// Do the horizontal lines (along the X)
			glVertex3f(i, 0, -50);
			glVertex3f(i, 10, -50);
		// Stop drawing lines
		glEnd();
	}


// Turn the lines GREEN
	glColor3ub(0, 255, 0);

	// Draw a 1x1 grid along the X and Z axis'
	for(i = -50; i <= 50; i += 1)
	{
		// Start drawing some lines
		glBegin(GL_LINES);
		
			// Do the horizontal lines (along the X)
			glVertex3f(i, 0, 50);
			glVertex3f(i, 10, 50);
		// Stop drawing lines
		glEnd();
	}
	glColor3ub(255, 255, 255);
}

void InitalizeGL()
{
	glEnable(GL_TEXTURE_2D);

	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
	glClearColor(0.0f, 0.0f, 155.0f, 0.0f);
	glClearDepth(1.0f);	
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	CSky::Get()->SetSkyDir("Data\\");
	CSky::Get()->SetSkyInfo(50, 50, 50);
}

void DrawGL()
{
	static CVector Rotation, Position;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	
	glLoadIdentity();

	CPlayer::Get()->UpdateObject(CTimer::Get()->GetTimeBasedValue());

	CCamera::Get()->GetRotation(Rotation);
	CPlayer::Get()->GetPosition(Position);

	glRotatef(Rotation.x, 1, 0, 0);
	glRotatef(90.0f + Rotation.y, 0, 1, 0);
	glTranslatef(-Position.x, -Position.y-0.5, -Position.z);
	
	glEnable(GL_DEPTH_TEST);
	/*Sky.UseTexture();

	glEnable(GL_TEXTURE_2D);

	glBegin(GL_QUADS);
		glTexCoord2f(0, 0); glVertex3f(-1, -1, -1);
		glTexCoord2f(1, 0); glVertex3f(1, -1, -1);
		glTexCoord2f(1, 1); glVertex3f(1, 1, -1);
		glTexCoord2f(0, 1); glVertex3f(-1, 1, -1);
	glEnd();
*/
	Draw3DSGrid();
	CSky::Get()->UpdateSky();
Example.SetFontColor(255, 255, 255, 1);
	
	// Turn the lines GREEN
	glColor3ub(0, 0, 255);
	//Example.RenderText(1, 0, "X");
	glBegin(GL_LINES);
		glVertex3f(-10, 0, 0);
		glVertex3f(10, 0, 0);
	glEnd();
	glColor3ub(0, 255, 0);
	//Example.RenderText(0, 1, "Y");
	glBegin(GL_LINES);
		glVertex3f(0, -10, 0);
		glVertex3f(0, 10, 0);
	glEnd();
	glColor3ub(255, 0, 0);

	//Example.RenderText(1, 1, "Z");
	glBegin(GL_LINES);
		glVertex3f(0, 0, -10);
		glVertex3f(0, 0, 10);
	glEnd();
	
	
	Example.SetFontColor(255, 255, 255, 1);
	
	Example.RenderText(0, 0, "FPS: %d", (int)CTimer::Get()->GetFPS());

	CVector tempPosition;
	CPlayer::Get()->GetPosition(tempPosition);
	
	Example.RenderText(0, 460, "X: %f Y: %f Z: %f", tempPosition.x, tempPosition.y, tempPosition.z);
	glColor4ub(255, 255, 255, 1);	
	
}

class CEngine
{
	public:
		static CEngine *Get()
		{
			if(!Instance)
				Instance = new CEngine;
			return Instance;
		}
	
		CEngine();
		~CEngine();

		void RequestInstance(CWindows &Windows);

		void InitalizeEngine();
		void DestroyEngine();

		void UpdateEngine(MSG Msg);

		void CheckExtensions();

	private:
		static CEngine *Instance;
		CWindows WindowInstance;
		//CGame *GameInstance;  for later use. make sure you include game and update it here tooo

		WININFO WindowInfo;
};

CEngine *CEngine::Instance = 0;

CEngine::CEngine()
{

}

CEngine::~CEngine()
{
	
}

void CEngine::RequestInstance(CWindows &Windows)
{
	Windows = WindowInstance;
}

void CEngine::InitalizeEngine()
{
	WindowInfo.Name = ProjectName;
	WindowInfo.FullScreen = false;
	WindowInfo.SizeX = 640;
	WindowInfo.SizeY = 480;
	WindowInfo.Bpp = 16;

	CLog::Get()->RequestExtensions();

	WindowInstance.CreateOpenGLWindow(&WindowInfo);

	CTimer::Get()->StartTimer();

	CCamera::Get()->InitalizeCamera();

	InitalizeGL();

	Example.LoadFont(FONT_WINDOWS, 25, "Courier New");

	Sky = CTexture::Get()->LoadTexture("Data\\Textures\\Sky.bmp");
}

void CEngine::UpdateEngine(MSG Msg)
{
	WindowInstance.UpdateOpenGLWindow(Msg);
	//Also update game here too!
	//Update systems too
	
	CTimer::Get()->UpdateTimer();

	CCamera::Get()->UpdateCamera();

	CPlayer::Get()->UpdateObject(CTimer::Get()->GetTimeBasedValue());

	DrawGL();

	glFlush();
	SwapBuffers(WindowInstance.GetHDC());

	Sleep(1);
}

void CEngine::DestroyEngine()
{
	WindowInstance.KillOpenGLWindow();

	CLog::Get()->UnLoad();

	Sky.KillObject();
}

void CEngine::CheckExtensions()
{
	



}
