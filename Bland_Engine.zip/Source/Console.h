//MAKE IT LOOK BEATUFIUL
//use the idea of fucntioin pointers to organize it in to subdivisons
//and load the code.. but changing varibles with all the private shit..
//errrrrrrrrrrrrrr. i might need alot of functions.
///or maybe make a friend in all the other classses
// then i would have control to each varible :_)