////////////////////////////////////////////
//					Texture
////////////////////////////////////////////

#pragma once

#include "Globals.h"
#include "Log.h"
#include "Image.h"

class CTexture
{
	public:
		static CTexture *Get()
		{
			if(Instance)
				Instance = new CTexture;
			return Instance;
		}

		CFileInfo LoadTexture(char *File);
		unsigned char *LoadTextureData(char *File);

	private:
		static CTexture *Instance;

		unsigned char *Data;
};

CTexture *CTexture::Instance = 0;

CFileInfo CTexture::LoadTexture(char *File)
{
	char Temp[64];
	char TempBuf[64], tempBuf[64];
	
	CFileInfo TempInfo;

	/*
		if(!strlen(File))
		{
			CFileInfo Error;

			Error.SetInfo(NULL,NULL, NULL, NULL, NULL);

			return Error;
		}
	*/

	int m;
	bool Done = false;
	
	strcpy(Temp, "");

	m = strlen(File);

	for(int x = 0; x < m; x++)
	{
		sprintf(TempBuf, "%c", File[x]);

		if(strcmp(TempBuf, ".") == 0)
		{
			for(int y = x; y < m; y++)
			{
				sprintf(tempBuf, "%c", File[y]);

				strcat(Temp, tempBuf);
			}
		
			Done = true;
		}

		if(Done)
			break;
	}

	if(strcmp(Temp, ".bmp") == 0)
		TempInfo = CImage::Get()->LoadBMP(File);

	if(strcmp(Temp, ".jpg") == 0)
		TempInfo = CImage::Get()->LoadJPEG(File);
		
	if(strcmp(Temp, ".tga") == 0)
		TempInfo = CImage::Get()->LoadTGA(File);
;
	if(strcmp(Temp, ".gif") == 0)
		TempInfo = CImage::Get()->LoadGIF(File);

	if(strcmp(Temp, ".emf") == 0)
		TempInfo = CImage::Get()->LoadEMF(File);

	if(strcmp(Temp, ".ico") == 0)
		TempInfo = CImage::Get()->LoadICO(File);

	if(strcmp(Temp, ".wmf") == 0)
		TempInfo = CImage::Get()->LoadWMF(File);

	if(TempInfo.SizeX == 0)
		CLog::Get()->WriteError("Error Occured in: %s", File);

	return TempInfo;
}

unsigned char *CTexture::LoadTextureData(char *File)
{
	char Temp[64];

	char TempBuf[64], tempBuf[64];
	int m;
	
	bool Done = false;

	strcpy(Temp, "");

	m = strlen(File);

	for(int x = 0; x < m; x++)
	{
		sprintf(TempBuf, "%c", File[x]);

		if(strcmp(TempBuf, ".") == 0)
		{
			for(int y = x; y < m; y++)
			{
				sprintf(tempBuf, "%c", File[y]);
				MsgBox("%d", x);

				strcat(Temp, tempBuf);
			}
		
			Done = true;
		}

		if(Done)
			break;
	}

	if(strcmp(Temp, ".bmp"))
		CImage::Get()->LoadBMPData(File, Data);
	
	if(Data = NULL)
		CLog::Get()->WriteError("A Error Occured in: %s", File);

	return Data;
}