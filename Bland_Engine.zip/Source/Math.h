/////////////////////////////////////////////
//					Math
/////////////////////////////////////////////

////////FIND A ACCELORATED SIN AND COS. AT PROGRAMMING UNLIMITED!! AT NEHE"S SITE!!

#pragma once

#include "Globals.h"

#include <math.h>

const float PI = 3.141592653589793f;
const float PIOVER180 = PI/180.0f;

const float DEGTORAD = PIOVER180;
const float RADTODEG = 1/PIOVER180;

const float EPSILON = 1e-6f;
const float INFINITY = 1e19f;

const float GRAVITY = -32.174f;

/*
inline float sqrt(float x)
{
	int iter = 0;
	static float error = 0.0001f;
	float guess = x;
	float result = x;

	while(abs(x-guess*guess) > error)
	{
		guess = result;
		result = 0.5f*(guess+x/guess);
		if(++iter > 100)
			break;
	}

	return result;
}
*/