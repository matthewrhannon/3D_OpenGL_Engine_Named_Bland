
//********************************************
//					Globals
//********************************************

#pragma once

#define EngineName "Bland Engine"
#define ProjectName "Bland Engine"
#define EngineVersion "0.01"

#define Debug_Mode 0

#define Scale_Down WIN32_LEAN_AND_MEAN

#define inline __forceinline

#define GL_CLAMP_TO_EDGE 0x812F 

#define SafeDelete(Object) {if(Object) delete Object; Object = 0}

#define QuickMsg(Text) MessageBox(NULL, Text, "Quick Message", MB_OK)

void MsgBox(char *Text, ...)
{
	va_list List;
	char Temp[256];

	va_start(List, Text);
		vsprintf(Temp, Text, List);
	va_end(List);

	MessageBox(NULL, Temp, "Information", MB_OK);
}

void MsgBoxError(char *Text, ...)
{
	va_list List;
	char Temp[256], Temp1[256];

	va_start(List, Text);
		vsprintf(Temp, Text, List);
	va_end(List);

	sprintf(Temp1, "Error: %s", Temp);

	MessageBox(NULL, Temp1, "Application Error", MB_OK);
}

#ifndef VK_1 
	#define VK_1 48
	#define VK_2 49
	#define VK_3 50
	#define VK_4 51
	#define VK_5 52
	#define VK_6 53
	#define VK_7 54
	#define VK_8 55
	#define VK_9 56
	#define VK_0 57
#endif

#ifndef VK_A
	#define VK_A 65
	#define VK_B 66
	#define VK_C 67
	#define VK_D 68
	#define VK_E 69
	#define VK_F 70
	#define VK_G 71
	#define VK_H 72
	#define VK_I 73
	#define VK_J 74
	#define VK_K 75
	#define VK_L 76
	#define VK_M 77
	#define VK_N 78
	#define VK_O 79
	#define VK_P 80
	#define VK_Q 81
	#define VK_R 82
	#define VK_S 83
	#define VK_T 84
	#define VK_U 85
	#define VK_V 86
	#define VK_W 87
	#define VK_X 88
	#define VK_Y 89
	#define VK_Z 90
#endif


extern HDC g_hdc;
extern HWND g_hwnd;



