
//*******************************************
//					Bland Engine
//*******************************************

#include <windows.h>
#include <stdio.h>
#include <fstream>
#include <math.h>
#include <string.h>

#include <stdarg.h> 
#include <time.h>

#include <olectl.h>	

#include "gl/gl.h" 				
#include "gl/glu.h"	
#include "gl/glaux.h"		
//#include "gl/Glext.h"				

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glaux.lib")

#include "Engine.h"

#include "BoundingBox.h"
#include "Camera.h"
#include "Collision.h"
#include "Console.h"
#include "Constants.h"
#include "Enemy.h"
#include "Entity.h"
#include "Extensions.h"
#include "Fog.h"
#include "Frustum.h"
#include "Globals.h"
#include "Guns.h"
#include "Hud.h"
#include "Image.h"
#include "Input.h"
#include "LoadingScreen.h"
#include "Log.h"
#include "Math.h"
#include "Menu.h"
#include "Models.h"
#include "Object.h"
#include "Particle.h"
#include "Player.h"
#include "Game.h"
#include "Sky.h"
#include "Sound.h"
#include "Structures.h"
#include "Terrain.h"
#include "Text.h"
#include "Texture.h"
#include "Timer.h"
#include "Varibles.h"
#include "Vector.h"
#include "Windows98.h"
#include "World.h"

#include "NeheFont.h"
#include "WindowFont.h"
#include "SliderFont.h"

MSG Msg;

int WINAPI WinMain(HINSTANCE hInstance,	HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)		
{			
	bool Done;	
	
	Done = false;

	CEngine::Get()->InitalizeEngine();

	for(;;)								
	{
		if (GetAsyncKeyState(VK_ESCAPE))			
		{
			break;					
		}
		else							
		{
			CEngine::Get()->UpdateEngine(Msg);	
		}
	}

	CEngine::Get()->DestroyEngine();					
	return (Msg.wParam);						
}