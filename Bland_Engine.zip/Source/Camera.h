/////////////////////////////////////////////
//					Camera
/////////////////////////////////////////////

#pragma once

#include "Globals.h"
#include "Input.h"
#include "Math.h"
#include "Vector.h"
#include "Player.h"

//1 for regular FPS type, 2 for fly through 
int CAMERA_STATE = 1;

class CCamera
{
	public:
		static CCamera *Get()
		{
			if(!Instance)
				Instance = new CCamera;
			return Instance;
		}

		void InitalizeCamera();
		
		void UpdateCamera();

		void GetRotation(CVector &Rotation);

		void SetCameraState(int State);
		void GetCameraState(int &State);

	private:
		static CCamera *Instance;

		float RotX, RotY, RotZ;

		int MouseX, MouseY;
		float MouseX1, MouseY1;

		float Speed;
};

CCamera *CCamera::Instance = 0;

void CCamera::InitalizeCamera()
{
	RotX = 0;
	RotY = 0;
	RotZ = 0;

	Speed = 2;
}

void CCamera::UpdateCamera()
{
	CVector Velocity;
	
	CInput::Get()->GetMouseMovement(MouseX, MouseY);

	MouseX1 = (float)CInput::Get()->GetMouseSensitivity() * MouseX;
	MouseY1 = (float)CInput::Get()->GetMouseSensitivity() * MouseY;

    RotX -= MouseY1;
	if(RotX > 90.0f)
		RotX = 90.0f;
	if(RotX < -90.0f)
		RotX = -90.0f;
    RotY -= MouseX1;

	Velocity = CPlayer::Get()->GetVelocity();

	if(CInput::Get()->CheckKey(VK_W))
	{
		Velocity.x += Speed*cosf(RotY*DEGTORAD);
		if(CAMERA_STATE == 2)
			Velocity.y += Speed*-sinf(RotX*DEGTORAD);
		Velocity.z += Speed*sinf(RotY*DEGTORAD);
	}
	
	if(CInput::Get()->CheckKey(VK_S))
	{
		Velocity.x += -Speed*cosf(RotY*DEGTORAD);
		if(CAMERA_STATE == 2)
			Velocity.y += -Speed*-sinf(RotX*DEGTORAD);
		Velocity.z += -Speed*sinf(RotY*DEGTORAD);
	}

	if(CInput::Get()->CheckKey(VK_A))
	{
		Velocity.x += -Speed*cosf((RotY+90.0f)*DEGTORAD);
		Velocity.z += -Speed*sinf((RotY+90.0f)*DEGTORAD);
	}

	if(CInput::Get()->CheckKey(VK_D))
	{
		Velocity.x += Speed*cosf((RotY+90.0f)*DEGTORAD);
		Velocity.z += Speed*sinf((RotY+90.0f)*DEGTORAD);
	}

	if(CInput::Get()->CheckKey(VK_INSERT))
	{
		float Sense = CInput::Get()->GetMouseSensitivity();
		Sense += 0.01f;
	
		if(Sense > 1.0f)
			Sense = 1.0f;

		CInput::Get()->SetMouseSense(Sense);
	}

	if(CInput::Get()->CheckKey(VK_DELETE))
	{
		float Sense = CInput::Get()->GetMouseSensitivity();
		Sense -= 0.01f;

		if(Sense < 0.01f)
			Sense = 0.01f;

		CInput::Get()->SetMouseSense(Sense);
	}

	CPlayer::Get()->SetVelocity(Velocity);
}

void CCamera::GetRotation(CVector &Rotation)
{
	Rotation.x = RotX;
	Rotation.y = RotY;
	Rotation.z = RotZ;
}

void CCamera::SetCameraState(int State)
{
	if(State > 2 || State < 1)
		State = 1;

	CAMERA_STATE = State;
}

void CCamera::GetCameraState(int &State)
{
	CAMERA_STATE = State;
}