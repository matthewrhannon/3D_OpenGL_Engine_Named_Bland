//Febuary 17, 2002
//By Matt H.

#ifndef _SKY_
#define _SKY_

#include "Globals.h"
#include "Constants.h"
#include "Texture.h"
#include "Log.h"

class CSky
{
	public:
		static CSky *Get()
		{
			if(!Instance)
				Instance = new CSky;
			return Instance;
		}
		void SetSkyDir(char *Directory1);
		void SetSkyInfo(float Length1, float Width1, float Height1);
		//void SetSkyInfo(int X1, int Y1, int Length1, int Width1, int Height1);
		void UpdateSky();

	protected:
		~CSky()
		{
			if(Instance)
				delete Instance;
			Instance = 0;
		}

	private:
		static CSky *Instance;
		float Length, Width, Height;
		//int X, Y;
		char Directory[64];
		char Path[40];
		//CTexture Top, Bottom, Right, Left, Front, Back;
		CFileInfo Top, Bottom, Right, Left, Front, Back;
};



CSky *CSky::Instance = 0;

void CSky::SetSkyDir(char *Directory1)
{
	//if(Directory[strlen(Directory) - 1] != '/')
	//	Directory[strlen(Directory) - 1] = '/';
	strcpy(Directory, Directory1);
}

void CSky::SetSkyInfo(float Length1, float Width1, float Height1)
{
	sprintf(Path, "Data\\Sky\\Front.bmp");
	Front = CTexture::Get()->LoadTexture(Path);
	sprintf(Path, "Data\\Sky\\Back.bmp");
	Back = CTexture::Get()->LoadTexture(Path);
	sprintf(Path, "Data\\Sky\\Left.bmp");
	Left = CTexture::Get()->LoadTexture(Path);
	sprintf(Path, "Data\\Sky\\Right.bmp");
	Right = CTexture::Get()->LoadTexture(Path);
	sprintf(Path, "Data\\Sky\\Up.bmp");
	Top = CTexture::Get()->LoadTexture(Path);
	sprintf(Path, "Data\\Sky\\Down.bmp");
	Bottom = CTexture::Get()->LoadTexture(Path);

	Length = Length1;
	Width = Width1;
	Height = Height1;
}

/*
void CSky::SetSkyInfo(int X1, int Y1, int Length, int Width1, int Height1)
{
	sprintf(Path, "%sFront.bmp", Directory);
	Front.LoadTexture(Path);
	sprintf(Path, "%sBack.bmp", Directory);
	Back.LoadTexture(Path);
	sprintf(Path, "%sLeft.bmp", Directory);
	Left.LoadTexture(Path);
	sprintf(Path, "%sRight.bmp", Directory);
	Right.LoadTexture(Path);
	sprintf(Path, "%sTop.bmp", Directory);
	Top.LoadTexture(Path);
	sprintf(Path, "%sBottom.bmp", Directory);
	Bottom.LoadTexture(Path);
	
	Length = Length1;
	Width = Width1;
	Height = Height1;

	X = X1;
	Y = Y1;
}
*/

void CSky::UpdateSky()
{
	glEnable(GL_TEXTURE_2D);

	//Length = Length/2;
	//Width = Width/2;
	//Height = Height/2;

	Front.UseTexture();
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-Length, -Height, -Width); 
		glTexCoord2f(1.0f, 0.0f); glVertex3f(Length, -Height, -Width); 
		glTexCoord2f(1.0f, 1.0f); glVertex3f(Length, Height, -Width); 
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-Length, Height, -Width); 
	glEnd();

	Back.UseTexture();
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-Length, -Height, Width); 
		glTexCoord2f(1.0f, 0.0f); glVertex3f(Length, -Height, Width); 
		glTexCoord2f(1.0f, 1.0f); glVertex3f(Length, Height, Width); 
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-Length, Height, Width); 
	glEnd();

	Top.UseTexture();
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-Length, Height, -Width); 
		glTexCoord2f(1.0f, 0.0f); glVertex3f(Length, Height, -Width); 
		glTexCoord2f(1.0f, 1.0f); glVertex3f(Length, Height, Width); 
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-Length, Height, Width); 
	glEnd();

	Bottom.UseTexture();
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-Length, -Height, -Width); 
		glTexCoord2f(1.0f, 0.0f); glVertex3f(Length, -Height, -Width); 
		glTexCoord2f(1.0f, 1.0f); glVertex3f(Length, -Height, Width); 
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-Length, -Height, Width); 
	glEnd();

	Right.UseTexture();
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-Length, -Height, -Width); 
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-Length, -Height, Width); 
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-Length, Height, Width); 
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-Length, Height, -Width); 
	glEnd();

	Left.UseTexture();
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(Length, -Height, -Width); 
		glTexCoord2f(1.0f, 0.0f); glVertex3f(Length, -Height, Width); 
		glTexCoord2f(1.0f, 1.0f); glVertex3f(Length, Height, Width); 
		glTexCoord2f(0.0f, 1.0f); glVertex3f(Length, Height, -Width); 
	glEnd();

	glDisable(GL_TEXTURE_2D);
}

#endif