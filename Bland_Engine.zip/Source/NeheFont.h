
//********************************************
//					NeheFont
//********************************************


#pragma once

#include "Globals.h"
#include "Texture.h"

#define FontPath "Data/Textures/Font.bmp"

class CNeheFont
{
	public:
		CNeheFont();
		~CNeheFont();

		void BuildFont();
		
		void RenderText(int x, int y, char *String);
		void SetTextSize(int x, int y);
		void SetFontColor(int pRed, int pGreen, int pBlue, int pAlpha);

		void KillFont();

	private:
		CFileInfo FontImage;
		
		int SizeX, SizeY;

		int Red, Green, Blue, Alpha;

		int base;
		int set;

};

CNeheFont::CNeheFont()
{
	SizeX = 1;
	SizeY = 1;

	set = 0;

	Red = 255;
	Green = 255;
	Blue = 255;
	Alpha = 1;
}

CNeheFont::~CNeheFont()
{
	KillFont();
}

void CNeheFont::KillFont()
{
	glDeleteLists(base, 256);
	FontImage.KillObject();
}

void CNeheFont::SetFontColor(int pRed, int pGreen, int pBlue, int pAlpha)
{
	if(pRed > 255)
		pRed = 255;
	if(pGreen > 255)
		pGreen = 255;
	if(pBlue > 255)
		pBlue = 255;

	Red = pRed;
	Green = pGreen;
	Blue = pBlue;

	Alpha = pAlpha;
}

void CNeheFont::SetTextSize(int x, int y)
{
	SizeX = x;
	SizeY = y;
}

void CNeheFont::BuildFont()							
{
	float	cx;										
	float	cy;										

	FontImage = CTexture::Get()->LoadTexture(FontPath);

	base = glGenLists(256);							
		
	FontImage.UseTexture();
	
	for (int loop=0; loop<256; loop++)						
	{
		cx=float(loop%16)/16.0f;					
		cy=float(loop/16)/16.0f;					

		glNewList(base+loop,GL_COMPILE);				
			glBegin(GL_QUADS);						
				glTexCoord2f(cx,1-cy-0.0625f);		
				glVertex2i(0,0);					
				glTexCoord2f(cx+0.0625f,1-cy-0.0625f);	
				glVertex2i(16,0);					
				glTexCoord2f(cx+0.0625f,1-cy);		
				glVertex2i(16,16);					
				glTexCoord2f(cx,1-cy);			
				glVertex2i(0,16);					
			glEnd();								
			glTranslated(10,0,0);					
		glEndList();	
	}	
}

void CNeheFont::RenderText(int x, int y, char *String)	
{
	if (set>1)
		set=1;
	
	glPushAttrib(GL_ALL_ATTRIB_BITS);
		
		glColor4f((float)Red, (float)Green, (float)Blue, (float)Alpha);
	
		glBlendFunc(GL_SRC_ALPHA,GL_ONE);
		glEnable(GL_BLEND);

		glDisable(GL_LIGHTING);
		
		glEnable(GL_TEXTURE_2D);
			glEnable(GL_BLEND);
				FontImage.UseTexture();
				glDisable(GL_DEPTH_TEST);						
					glMatrixMode(GL_PROJECTION);					
					glPushMatrix();									
						glLoadIdentity();									
						glOrtho(0,640,0,480,-1,1);							
						glMatrixMode(GL_MODELVIEW);							
						glPushMatrix();										
							glLoadIdentity();									
							glTranslated(x,y,0);						
							glScalef((float)SizeX, (float)SizeY, 1);
							glListBase(base-32+(128*set));						
							glCallLists(strlen(String),GL_BYTE,String);			
							glMatrixMode(GL_PROJECTION);					
						glPopMatrix();										
					glMatrixMode(GL_MODELVIEW);						
					glPopMatrix();								
				glEnable(GL_DEPTH_TEST);							
			glDisable(GL_BLEND);
		glDisable(GL_TEXTURE_2D);

	glPopAttrib();

	glColor4ub(255, 255, 255, 1);	
}




