////////////////////////////////////////////
//			      	Terrain				  //
////////////////////////////////////////////

#pragma once //pragma uno

#include "Globals.h"
#include "Frustum.h"
#include "Fog.h"
#include "Occlusion.h" //Maybe take out later
#include "Camera.h"
#include "Log.h"
#include "Texture.h"
#include "Structures.h"

#define Path "Data/Terrain/"

class CTerrain
{
	public:
		CTerrain();
		~CTerrain();
		
		bool LoadTerrain(char *FilePath);
		void UpdateTerrain();

		void RebuildTerrain();

		void SetTextureDuplication(int Amount);
		void SetTerrainHeightScale(int Height);
		void SetTerrainStepSize(int StepSize1);
		void SetTerrainTextureAmount(int Amount);

		void RandomTerrainData(int Amount);

		bool DestroyTerrain();

		void GetTerrainData(TERRAINDATA &Data1);

		float GetTerrainHeight(int x, int z);
	
	private:
		bool Random;

		char *TerrainData;
		char *TerrainNormals;
		
		int DuplicationAmount;
		int HeightScale;
		int StepSize;

		int AmountOfTextures;
		int AmountOfRandomTerrain;

		char *TerrainPath;
		int TerrainSize;

		CFileInfo *Textures;
		CFileInfo *Terrain;

		TERRAINDATA Data;
};

CTerrain::CTerrain()
{
	Random = false;

	TerrainData = NULL;
	TerrainNormals = NULL;

	DuplicationAmount = 5;
	HeightScale = 1;
	StepSize = 1;

	AmountOfTextures = 1;
	AmountOfRandomTerrain = 0;

	Textures = NULL;
	Terrain = NULL;

	TerrainSize = 0;
	TerrainPath = NULL;

	strcpy(Data.TerrainPath, TerrainPath);

	Data.TerranSize = TerrainSize;
	Data.AmountOfTextures = AmountOfTextures;
	Data.AmountOfRandomTerrain = AmountOfRandomTerrain;
	Data.DuplicationAmount = DuplicationAmount;
	Data.HeightScale = HeightScale;
	Data.StepSize = StepSize;
	Data.Random = Random;
}

CTerrain::~CTerrain()
{






}

bool CTerrain::LoadTerrain(char *FilePath)
{




	return true;
}

void CTerrain::UpdateTerrain()
{






}

void CTerrain::RebuildTerrain()
{






}

void CTerrain::SetTextureDuplication(int Amount)
{
	DuplicationAmount = Amount;
	Data.DuplicationAmount = Amount;
}

void CTerrain::SetTerrainHeightScale(int Height)
{
	HeightScale = Height;
	Data.HeightScale = Height;
}

void CTerrain::SetTerrainStepSize(int StepSize1)
{
	StepSize = StepSize1;
	Data.StepSize = StepSize1;
}

void CTerrain::RandomTerrainData(int Amount)
{
	AmountOfRandomTerrain = Amount;
	Data.AmountOfRandomTerrain = Amount;

	Random = true;
	Data.Random = true;
}

void CTerrain::SetTerrainTextureAmount(int Amount)
{
	AmountOfTextures = Amount;
	Data.AmountOfTextures = Amount;
}

bool CTerrain::DestroyTerrain()
{



	return true;
}

void CTerrain::GetTerrainData(TERRAINDATA &Data1)
{
	Data1 = Data;
}

float CTerrain::GetTerrainHeight(int x, int z)
{


	return 1;
}