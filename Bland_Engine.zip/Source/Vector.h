////////////////////////////////////////////
//					Vector
////////////////////////////////////////////

#pragma once

#include "Globals.h"

class CVector
{
	public:
		CVector();
		~CVector();

		void Clear();
		void Set(CVector Vector);

		CVector AddVectors(CVector One, CVector Two);
		CVector SubtractVectors(CVector One, CVector Two);

		CVector Mutiply(CVector One, float Two);

		CVector MutiplyVectors(CVector One, CVector Two);
		CVector DivideVectors(CVector One, CVector Two);

		CVector NormalizeVector();

		float VectorLength();

		float x;
		float y;
		float z;
};

CVector::CVector()
{
	x = 0;
	y = 0;
	z = 0;
}

CVector::~CVector()
{

}

void CVector::Clear()
{
	x = 0;
	y = 0;
	z = 0;
}

void CVector::Set(CVector Vector)
{
	x = Vector.x;
	y = Vector.y;
	z = Vector.z;
}

CVector CVector::AddVectors(CVector One, CVector Two)
{
	CVector Temp;

	Temp.x = One.x + Two.x;
	Temp.y = One.y + Two.y;
	Temp.z = One.z + Two.z;

	return Temp;
}

CVector CVector::SubtractVectors(CVector One, CVector Two)
{
	CVector Temp;

	Temp.x = One.x - Two.x;
	Temp.y = One.y - Two.y;
	Temp.z = One.z - Two.z;

	return Temp;
}

CVector CVector::MutiplyVectors(CVector One, CVector Two)
{
	CVector Temp;

	Temp.x = One.x * Two.x;
	Temp.y = One.y * Two.y;
	Temp.z = One.z * Two.z;

	return Temp;
}

CVector CVector::Mutiply(CVector One, float Two)
{
	CVector Temp;

	Temp.x = One.x * Two;
	Temp.y = One.y * Two;
	Temp.z = One.z * Two;

	return Temp;
}

CVector CVector::DivideVectors(CVector One, CVector Two)
{
	CVector Temp;

	Temp.x = One.x / Two.x;
	Temp.y = One.y / Two.y;
	Temp.z = One.z / Two.z;

	return Temp;
}

CVector CVector::NormalizeVector()
{
	CVector Vector;

	Vector.Clear();
	
	return Vector;
}

float CVector::VectorLength()
{
	return (float)sqrt(x+x * y+y * z+z);
}
