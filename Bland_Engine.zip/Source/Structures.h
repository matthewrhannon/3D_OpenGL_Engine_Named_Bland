
//*******************************************
//					Structures
//*******************************************

#pragma once

#include "Globals.h"

struct WININFO
{
	char *Name;
	int SizeX;
	int SizeY;
	int Bpp;
	bool FullScreen;
};

struct FILEINFO
{
	char File[64];
	int SizeX;
	int SizeY;

	unsigned int ID;

	bool SkyBox;
};

/*
struct OPENGLINFO
{
	char Vendor[64];
	char Renderer[64];
	char Version[64];

	char Extensions[512];
};

extern OPENGLINFO GLInfo;
*/

struct TERRAINDATA
{
	char *TerrainPath;

	int TerranSize;
	
	int DuplicationAmount;
	int HeightScale;
	int StepSize;
	int AmountOfTextures;
	int AmountOfRandomTerrain;

	bool Random;
};

enum FrustumSide
{
	RIGHT	= 0,		
	LEFT	= 1,
	BOTTOM	= 2,	
	TOP		= 3,	
	BACK	= 4,		
	FRONT	= 5			
}; 

enum PlaneData
{
	A = 0,				
	B = 1,				
	C = 2,				
	D = 3			
};
