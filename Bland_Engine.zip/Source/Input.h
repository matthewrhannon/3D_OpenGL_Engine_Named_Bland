////////////////////////////////////////////
//					Input
////////////////////////////////////////////

#pragma once

#include "Globals.h"

class CInput
{
	public:
		static CInput *Get()
		{
			if(!Instance)
				Instance = new CInput;
			return Instance;
		}

		CInput()
		{
			MouseSense = 0.2f;
		}
		
		bool CheckKey(int Key);
		void GetMouseMovement(int &x, int &y);

		float GetMouseSensitivity();
		void SetMouseSense(float MouseSense1);

	private:
		static CInput *Instance;

		float MouseSense;
};

CInput *CInput::Instance = 0;

bool CInput::CheckKey(int Key)
{
	if(GetKeyState(Key) & 0x8000)
		return true;
	else 
		return false;
}

void CInput::GetMouseMovement(int &x, int &y)
{
	x = 0;
	y = 0;

	static RECT WindowSize;
	static POINT CurPoint;

	GetWindowRect(g_hwnd, &WindowSize);
	
	POINT CenterPoint = { WindowSize.right/2, WindowSize.bottom/2 };

	GetCursorPos(&CurPoint);

	x = CenterPoint.x - CurPoint.x;
	y = CenterPoint.y - CurPoint.y;
	
	SetCursorPos(CenterPoint.x, CenterPoint.y);
}

void CInput::SetMouseSense(float MouseSense1)
{
	MouseSense = MouseSense1;
}

float CInput::GetMouseSensitivity()
{
	return MouseSense;
}