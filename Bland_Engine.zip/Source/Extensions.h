//called by engine. checks for needed extensions through a list of the ones collomly use
//using a bool varible. and if not supported. if you have to use it..
//make other code and warn the player of this. and maybe even quit the program

#pragma once

#include "Globals.h"
#include "Engine.h"

bool GetExtension(char *Text)
{
	char *Extensions;

	Extensions = (char *)glGetString(GL_EXTENSIONS);

	if(strstr(Text, Extensions))
		return true;
	else 
		return false;
}
