//Febuary 6, 2002
//By Matt H.

#include "Text.h"

CFont::CFont(char *FontName, int Height)
{
	BuildFont(FontName, Height);
	Red = 0.0f;
	Green = 0.0f;
	Blue = 0.0f;
	Alpha = 1.0f;
}

CFont::~CFont()
{	
	KillFont();
}

void CFont::BuildFont(char *FontName, int Height)					
{
	HFONT	font;									
	HFONT	oldfont;							

	base = glGenLists(96);							

	font = CreateFont(Height, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY,	FF_DONTCARE | DEFAULT_PITCH, FontName);					
	
	oldfont = (HFONT)SelectObject(CWindows98::Get()->GetHDC(), font);          
	wglUseFontBitmaps(CWindows98::Get()->GetHDC(), 32, 96, base);				
	SelectObject(CWindows98::Get()->GetHDC(), oldfont);						
	DeleteObject(font);								
}

void CFont::PrintEx(int x, int y, char *String, ...)			
{
	char text[256];							
	va_list	ap;									

	if (String == NULL)								
		return;											

	va_start(ap, String);								
	    vsprintf(text, String, ap);					
	va_end(ap);										

	glColor4f(Red, Green, Blue, Alpha);
	
	glMatrixMode(GL_PROJECTION);					
		glPushMatrix();									
		glLoadIdentity();									
		glOrtho(0,640,0,480,-1,1);							
		glMatrixMode(GL_MODELVIEW);							
			glPushMatrix();										
			glLoadIdentity();									
			glTranslated(x,y,0);							
			glPushAttrib(GL_LIST_BIT);						
				glListBase(base - 32);							
				glCallLists(strlen(text), GL_UNSIGNED_BYTE, text);	
			glPopAttrib();	
		glMatrixMode(GL_PROJECTION);					
		glPopMatrix();										
		glMatrixMode(GL_MODELVIEW);						
		glPopMatrix();									
}

void CFont::Print(int x, int y, char *String)
{
	if(String == NULL)
		return;
	
	glColor4f(Red, Green, Blue, Alpha);
	
	glMatrixMode(GL_PROJECTION);					
		glPushMatrix();									
		glLoadIdentity();									
		glOrtho(0,640,0,480,-1,1);							
		glMatrixMode(GL_MODELVIEW);							
			glPushMatrix();										
			glLoadIdentity();									
			glTranslated(x,y,0);							
			glPushAttrib(GL_LIST_BIT);						
				glListBase(base - 32);							
				glCallLists(strlen(String), GL_UNSIGNED_BYTE, String);	
			glPopAttrib();	
		glMatrixMode(GL_PROJECTION);					
		glPopMatrix();										
		glMatrixMode(GL_MODELVIEW);						
		glPopMatrix();		
}


void CFont::KillFont()								
{
	glDeleteLists(base, 96);					
}

void CFont::SetColor(float Red1, float Green1, float Blue1, float Alpha1)
{
	Red = Red1;
	Green = Green1;
	Blue = Blue1;
	Alpha = Alpha1;
}

/*
void CText::BuildFont()							
{
	float	cx;										
	float	cy;										

	Font.LoadTexture("Data/Font/Font.bmp");

	base = glGenLists(256);							
		
	Font.UseTexture();
	
	for (int loop=0; loop<256; loop++)						
	{
		cx=float(loop%16)/16.0f;					
		cy=float(loop/16)/16.0f;					

		glNewList(base+loop,GL_COMPILE);				
			glBegin(GL_QUADS);						
				glTexCoord2f(cx,1-cy-0.0625f);		
				glVertex2i(0,0);					
				glTexCoord2f(cx+0.0625f,1-cy-0.0625f);	
				glVertex2i(16,0);					
				glTexCoord2f(cx+0.0625f,1-cy);		
				glVertex2i(16,16);					
				glTexCoord2f(cx,1-cy);			
				glVertex2i(0,16);					
			glEnd();								
			glTranslated(10,0,0);					
		glEndList();	
	}												
}


void CText::Print(int x, int y, char *String)	
{
	if (set>1)
		set=1;
	
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glColor4f(Red, Green, Blue, Alpha);
	glBlendFunc(GL_ONE,GL_ONE_MINUS_SRC_COLOR);
//	glBlendFunc(GL_ONE,GL_ONE);
	
	glColor3f(1.0f,1.0f,0.0f);

    glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glEnable(GL_BLEND);

	glDisable(GL_LIGHTING);
	
	
	glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
			Font.UseTexture();
			glDisable(GL_DEPTH_TEST);						
				glMatrixMode(GL_PROJECTION);					
				glPushMatrix();									
					glLoadIdentity();									
					glOrtho(0,640/Width,0,480/Height,-1,1);							
					glMatrixMode(GL_MODELVIEW);							
					glPushMatrix();										
					glLoadIdentity();									
					glTranslated(x,y,0);							

					glListBase(base-32+(128*set));						
					glCallLists(strlen(String),GL_BYTE,String);			
					glMatrixMode(GL_PROJECTION);					
				glPopMatrix();										
				glMatrixMode(GL_MODELVIEW);						
				glPopMatrix();								
			glEnable(GL_DEPTH_TEST);							
		glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glPopAttrib();
	glColor3ub(255, 255, 255);
}

void CText::PrintEx(int x, int y, char *String, ...)	
{
	if (set>1)
		set=1;
	
	glColor4f(Red, Green, Blue, Alpha);
	
	char Text[1024];								
	va_list ap;											

	va_start(ap, String);									
	    vsprintf(Text, String, ap);							
	va_end(ap);	
	
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	//glBlendFunc(GL_ONE,GL_ONE);
	
	glColor3f(1.0f,1.0f,0.0f);

    glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glEnable(GL_BLEND);

	glDisable(GL_LIGHTING);
    
	glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
			Font.UseTexture();
 			glDisable(GL_DEPTH_TEST);						
				glMatrixMode(GL_PROJECTION);					
				glPushMatrix();										
					glLoadIdentity();									
					glOrtho(0,640/Width,0,480/Height,-1,1);							
					glMatrixMode(GL_MODELVIEW);							
					glPushMatrix();									
					glLoadIdentity();									
					glTranslated(x,y,0);							
					glListBase(base-32+(128*set));						
					glCallLists(strlen(Text),GL_BYTE,Text);		
					glMatrixMode(GL_PROJECTION);					
				glPopMatrix();										
				glMatrixMode(GL_MODELVIEW);							
				glPopMatrix();									
			glEnable(GL_DEPTH_TEST);	
		glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);
	glPopAttrib();
	glColor3ub(255, 255, 255);
	
}
*/