//use bounding boxes here maybe even dirve some classes from thiss. maybe even use ray segments for collsion like bullets.
//dont know but about this. do collsion fo everyting. bullets. everything.............. or maybe a more
//efficent way would be to call a function with the speed, location, and direction and it returns true or false :)
//that would probley be more efficent ;)