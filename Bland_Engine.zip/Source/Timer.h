//*******************************************
//					Timer
//*******************************************

#pragma once

#include "Globals.h"
#include "Log.h"
#include "Engine.h"

class CTimer
{
	public:
		static CTimer *Get()
		{
			if(!Instance)
				Instance = new CTimer;
			return Instance;
		}

		CTimer();
		~CTimer();
		
		float GetTimePassed(float Time);
		float GetTimeBasedValue();	
		float GetRunningTime();
		void UpdateTimer();	
		float GetFPS();
		void StartTimer();
		void Reset();

	private:
		static CTimer *Instance;

		LARGE_INTEGER BaseTime;
		LARGE_INTEGER UpdateTime;
		LARGE_INTEGER SecondUpdateTime;
		LARGE_INTEGER Frequency;

		double fBaseTime;
		double fUpdateTime;
		double fSecondUpdateTime;

		float FramesPerSecond, FramesPerSecond1;

		bool Supported;
};

CTimer *CTimer::Instance = 0;

CTimer::CTimer()
{
	BaseTime.QuadPart = 0;
	UpdateTime.QuadPart = 0;
	SecondUpdateTime.QuadPart = 0;
	Frequency.QuadPart = 0;

	fBaseTime = 0;
	fUpdateTime = 0;
	fSecondUpdateTime = 0;

	CLog::Get()->LineDown();
	CLog::Get()->Write("Initalizing Timer");
	CLog::Get()->LineDown();
}

CTimer::~CTimer()
{
	if(Instance)
		delete Instance;
	Instance = 0;

	CLog::Get()->LineDown();
	CLog::Get()->Write("Finished Initalizing Timer");
}

void CTimer::StartTimer()
{
	if(QueryPerformanceCounter(&BaseTime))
	{
		CLog::Get()->Write("High Frequency Timer Supported -- Using it");

		QueryPerformanceCounter(&UpdateTime);
		QueryPerformanceFrequency(&Frequency);

		Supported = true;
	}
	else
	{
		CLog::Get()->Write("High Frequency Timer Not Supported -- Using Windows Timer");

		fBaseTime = GetTickCount();
		fUpdateTime = GetTickCount();

		Supported = false;
	}
}

void CTimer::UpdateTimer()
{
	if(Supported)
	{
		FramesPerSecond = float(Frequency.QuadPart / double(UpdateTime.QuadPart - SecondUpdateTime.QuadPart));

		SecondUpdateTime = UpdateTime;

		QueryPerformanceCounter(&UpdateTime);
	}
	else
	{
		FramesPerSecond1++;
		
		if((fUpdateTime - fSecondUpdateTime) >= 1000)
		{
			fSecondUpdateTime = fUpdateTime;

			FramesPerSecond = FramesPerSecond1;

			FramesPerSecond1 = 0;
		}

		fUpdateTime = GetTickCount();

	}
}

float CTimer::GetFPS()
{
	return FramesPerSecond;
}

float CTimer::GetRunningTime()
{
	static float RunningTime;

	if(Supported)
	{
		RunningTime = float((BaseTime.QuadPart - UpdateTime.QuadPart) / Frequency.QuadPart);	
	}
	else
	{
		RunningTime = float((fBaseTime - fUpdateTime) / 1000);
	}
	
	return (float)RunningTime * -1;
}

float CTimer::GetTimeBasedValue()
{
	return 1/FramesPerSecond;
}

float CTimer::GetTimePassed(float Time)
{
	return GetRunningTime() - Time;
}

void CTimer::Reset()
{
	BaseTime.QuadPart = 0;
	UpdateTime.QuadPart = 0;
	SecondUpdateTime.QuadPart = 0;
	Frequency.QuadPart = 0;

	fBaseTime = 0;
	fUpdateTime = 0;
	fSecondUpdateTime = 0;

	StartTimer();
}