
//********************************************
//					Windows
//********************************************

#pragma once

#include "Structures.h"
#include "Globals.h"
#include "Log.h"

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void ReSizeOpenGLWindow1(int SizeX, int SizeY);

bool Keys[255];
WININFO *WindowInformation;
float Perspective;

HDC g_hdc;
HWND g_hwnd;

class CWindows
{
	public:
		CWindows();
		~CWindows();
		
		bool CreateOpenGLWindow(WININFO *WindowInfo);
		bool UpdateOpenGLWindow(MSG Msg);
		void ReSizeOpenGLWindow(int SizeX, int SizeY);
		void KillOpenGLWindow();

		void DetectErrors();

		void SwitchTo3D();
		void SwitchTo2D();

		HWND GethWnd();
		HDC GetHDC();
		bool IsKey(char Key);
	
	private:
		HINSTANCE hInstance;			
		HGLRC hRC;	
		HWND hWnd;			
		HDC	hDC;
		int PixelFormat;
		WNDCLASS wc;
		DWORD dwExStyle;
		DWORD dwStyle;
		RECT WindowRect;

		bool ErrorCount[32];
};

CWindows::CWindows()
{
	hInstance = NULL;
	hRC = NULL;
	hWnd = NULL;
	hDC = NULL;
	Perspective = 45.0f;
}

CWindows::~CWindows()
{





}

void CWindows::DetectErrors()
{
	//See this is tricky
	//I ran into a large problem with the OpenglInfo and the initatlization of the windows with opengl
	//Soo this is a work around. If all goes well, it will return the log with the info
	//If there is an error it still spits out the shit but with no openglinfo.... strange isnt it...
	
	CLog::Get()->Load();

	CLog::Get()->Write("Starting to Create the Window");
	CLog::Get()->LineDown();

	CLog::Get()->Write("Starting to Fill in WindowData Structures");

	CLog::Get()->Write("Starting to Create Window");

	CLog::Get()->Write("Filling in Window Class");

	CLog::Get()->Write("Registering the Window with Windows");
	
	if(ErrorCount[0])
	{
		CLog::Get()->WriteError("Unable to Register Window Class");
		return;
	}
	
	if (WindowInformation->FullScreen)											
	{	
		CLog::Get()->Write("Enabling The Ability for FullScreen");
		
		CLog::Get()->Write("Filling OutData Structure for FullScreen");
	
		CLog::Get()->Write("Pushing Data Structure through FullScreen Function");
	}
	else
	{
		CLog::Get()->Write("Disabling FullScreen");
		
		CLog::Get()->Write("Disabling Finished");
	}
	
	if(ErrorCount[1])
	{
		CLog::Get()->WriteError("Unable to Enable the Ability for FullScreen");
		return;
	}

	CLog::Get()->Write("Filling Out Styles");
	CLog::Get()->Write("Adjusting Window for Full Size");
	CLog::Get()->Write("Trying to Create the Window");

	if(ErrorCount[2])
	{
		CLog::Get()->WriteError("Failed to Create Window");
		return;
	}

	CLog::Get()->Write("Filling out Pixel Format");
	CLog::Get()->Write("Trying to Create the DC");

	if(ErrorCount[3])
	{
		CLog::Get()->WriteError("Couldnt Create the DC");
		return;
	}	

	CLog::Get()->Write("Trying to Choose Pixel Format");
	
	if(ErrorCount[4])
	{	
		CLog::Get()->WriteError("Failed to Choose Pixel Format");
		return;
	}

	CLog::Get()->Write("Trying to Set the Pixel Format");
	
	if(ErrorCount[5])
	{
		CLog::Get()->WriteError("Failed to Set Pixel Format");
		return;
	}

	CLog::Get()->Write("Trying to Create OpenGL Context");
	
	if(ErrorCount[6])
	{
		CLog::Get()->WriteError("Failed to Create the OpenGL Context");
		return;
	}

	CLog::Get()->Write("Trying to Make the OpenGL Context Current");
	
	if(ErrorCount[7])
	{
		CLog::Get()->WriteError("Failed to Make the Context Current");
		return;
	}

	CLog::Get()->Write("Showing Window");
					
	CLog::Get()->Write("Setting Window to ForeGround");
	CLog::Get()->Write("Setting Focus to the Window");					
	CLog::Get()->Write("Resizing Window to support OpenGL");
		
	CLog::Get()->LineDown();
	CLog::Get()->Write("OpenGL Window Successfully Created");
}

bool CWindows::CreateOpenGLWindow(WININFO *WindowInfo)
{		
	for(int x = 0; x<32; x++)
		ErrorCount[x] = false;

	WindowInformation = WindowInfo;
	
	WindowRect.left = (long)0;			
	WindowRect.right = (long)WindowInformation->SizeX;	
	WindowRect.top = (long)0;			
	WindowRect.bottom = (long)WindowInformation->SizeY;				
	
	hInstance = GetModuleHandle(NULL);				
	wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wc.lpfnWndProc = (WNDPROC)WndProc;				
	wc.cbClsExtra = 0;							
	wc.cbWndExtra = 0;									
	wc.hInstance = hInstance;						
	wc.hIcon = LoadIcon(NULL, IDI_WINLOGO);		
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);		
	wc.hbrBackground = NULL;								
	wc.lpszMenuName	 = NULL;								
	wc.lpszClassName = EngineName;								

	if (!RegisterClass(&wc))									
	{
		ErrorCount[0] = true;

		DetectErrors();
	
		return false;										
	}
	
	if (WindowInformation->FullScreen)											
	{
		DEVMODE dmScreenSettings;								
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);	
		dmScreenSettings.dmPelsWidth = WindowInformation->SizeX;			
		dmScreenSettings.dmPelsHeight = WindowInformation->SizeY;			
		dmScreenSettings.dmBitsPerPel = WindowInformation->Bpp;		
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				WindowInformation->FullScreen = false;		
			}
			else
			{
				ErrorCount[1] = true;

				DetectErrors();
				return FALSE;								
			}
		}
	}

	if (WindowInformation->FullScreen)											
	{
		dwExStyle = WS_EX_APPWINDOW;							
		dwStyle = WS_POPUP;								
		ShowCursor(false);										
	}
	else
	{
		dwExStyle = WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			
		dwStyle = WS_OVERLAPPEDWINDOW;						
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		

	if (!(hWnd=CreateWindowEx(dwExStyle, EngineName, ProjectName, dwStyle |	WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0, 0, WindowRect.right-WindowRect.left, WindowRect.bottom-WindowRect.top, NULL, NULL, hInstance, NULL)))								
	{
		KillOpenGLWindow();						
		ErrorCount[2] = true;

		DetectErrors();
		return FALSE;						
	}

	static PIXELFORMATDESCRIPTOR pfd=				
	{
		sizeof(PIXELFORMATDESCRIPTOR),			
		1,											
		PFD_DRAW_TO_WINDOW |					
		PFD_SUPPORT_OPENGL |						
		PFD_DOUBLEBUFFER,							
		PFD_TYPE_RGBA,								
		WindowInformation->Bpp,									
		0, 0, 0, 0, 0, 0,						
		0,										
		0,										
		0,										
		0, 0, 0, 0,									
		16,										
		16,										
		0,										
		PFD_MAIN_PLANE,							
		0,										
		0, 0, 0										
	};

	if (!(hDC = GetDC(hWnd)))							
	{
		KillOpenGLWindow();						

		ErrorCount[3] = true;
		DetectErrors();
		return FALSE;							
	}

	if (!(PixelFormat = ChoosePixelFormat(hDC,&pfd)))	
	{
		KillOpenGLWindow();						
		
		ErrorCount[4] = true;
		DetectErrors();
		return FALSE;							
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		
	{
		KillOpenGLWindow();							

		ErrorCount[5] = true;
		DetectErrors();
		return FALSE;						
	}

	if (!(hRC = wglCreateContext(hDC)))			
	{
		KillOpenGLWindow();							
		
		ErrorCount[6] = true;
		DetectErrors();
		return FALSE;							
	}

	if(!wglMakeCurrent(hDC,hRC))				
	{
		KillOpenGLWindow();						

		ErrorCount[7] = true;
		DetectErrors();
		return FALSE;							
	}

	ShowWindow(hWnd,SW_SHOW);					

	SetForegroundWindow(hWnd);					

	SetFocus(hWnd);								

	ReSizeOpenGLWindow(WindowInformation->SizeX, WindowInformation->SizeY);

	DetectErrors();

	g_hdc = hDC;

	g_hwnd = hWnd;

	return true;		
}

bool CWindows::UpdateOpenGLWindow(MSG Msg)
{
	if (PeekMessage(&Msg, NULL, 0, 0, PM_REMOVE))	
	{
		if (Msg.message == WM_QUIT)				
		{
			return false;					
		}
		else									
		{
			TranslateMessage(&Msg);				
			DispatchMessage(&Msg);			
		}
	}
	return true;
}

void CWindows::ReSizeOpenGLWindow(int SizeX, int SizeY)
{
	if(SizeY == 0)									
		SizeY = 1;									
	
	glViewport(0, 0, SizeX, SizeY);						

	glMatrixMode(GL_PROJECTION);					
	glLoadIdentity();								

	gluPerspective(Perspective, SizeX/SizeY, 1.0f, 100.0f);

	WindowInformation->SizeX = SizeX;
	WindowInformation->SizeY = SizeY;

	glMatrixMode(GL_MODELVIEW);					
	glLoadIdentity();		
}


void ReSizeOpenGLWindow1(int SizeX, int SizeY)
{
	if(SizeY == 0)									
		SizeY = 1;									
	
	glViewport(0, 0, SizeX, SizeY);						

	glMatrixMode(GL_PROJECTION);					
	glLoadIdentity();								

	gluPerspective(Perspective, SizeX/SizeY, 1.0f, 100.0f);

	WindowInformation->SizeX = SizeX;
	WindowInformation->SizeY = SizeY;
	
	glMatrixMode(GL_MODELVIEW);					
	glLoadIdentity();		
}

void CWindows::KillOpenGLWindow()
{
	CLog::Get()->LineDown();

	CLog::Get()->Write("Starting to Destroy the Window");	
	CLog::Get()->LineDown();

	CLog::Get()->Write("Looking for FullScreen, if so, Disable it");
	if (WindowInformation->FullScreen)								
	{
		ChangeDisplaySettings(NULL,0);				
		ShowCursor(true);							
	}

	CLog::Get()->Write("If the HRC Handle is Valid, Destroy it");
	if (hRC)										
	{
		CLog::Get()->Write("Disabling OpenGL Current HRC");
		if (!wglMakeCurrent(NULL,NULL))				
		{
			CLog::Get()->WriteError("Unable to Disable the Current Context");
		}

		CLog::Get()->Write("Deleting HRC Handle");	
		if (!wglDeleteContext(hRC))					
		{
			CLog::Get()->WriteError("Unable to Delete the Current Context");
		}
	
		CLog::Get()->Write("Setting HRC to NULL");
		hRC=NULL;								
	}

	CLog::Get()->Write("If HDC is valid, release the DC Handle");
	if (hDC && !ReleaseDC(hWnd,hDC))					
	{
		CLog::Get()->WriteError("Unable to Release the DC");
		hDC=NULL;									
	}

	CLog::Get()->Write("If HWND Handle is valid, Destroy the Window");
	if (hWnd && !DestroyWindow(hWnd))					
	{
		CLog::Get()->WriteError("Unable to Destroy the Window");
		hWnd=NULL;									
	}

	CLog::Get()->Write("UnRegistering the Window Class");
	if (!UnregisterClass(EngineName, hInstance))		
	{
		CLog::Get()->WriteError("Unable to UnRegister the Window");
		hInstance=NULL;								
	}

	CLog::Get()->LineDown();
	CLog::Get()->Write("Finished Destroying the Window");
}

void CWindows::SwitchTo2D()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0,640,480,0,-1,1);
	glMatrixMode(GL_MODELVIEW);
}

void CWindows::SwitchTo3D()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(Perspective, WindowInformation->SizeX/WindowInformation->SizeY, 1.0f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
}

HDC CWindows::GetHDC()
{
	return hDC;
}

HWND CWindows::GethWnd()
{
	return hWnd;
}

bool CWindows::IsKey(char Key)
{
	if(Keys[Key])
		return true;
	else 
		return false;

	return false;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)			
{
	switch (uMsg)								
	{
		case WM_SYSCOMMAND:						
		{
			switch (wParam)						
			{
				case SC_SCREENSAVE:					
				case SC_MONITORPOWER:				
				return 0;						
			}
			break;									
		}

		case WM_KEYDOWN:
		{
			Keys[wParam] = true;
			return 0;
		}

		case WM_KEYUP:
		{
			Keys[wParam] = false;
			return 0;
		}

		case WM_CLOSE:								
		{
			PostQuitMessage(0);					
			return 0;						
		}

		case WM_SIZE:							
		{
			ReSizeOpenGLWindow1(LOWORD(lParam),HIWORD(lParam));  
			return 0;						
		}
	}

	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

