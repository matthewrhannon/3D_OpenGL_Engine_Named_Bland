//just make lkook nice
//have option to set text to say waht you are doing and loadign!