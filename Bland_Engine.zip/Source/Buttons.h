///scale text on botton with size of botton
//:)))